#!/usr/bin/env node
/**
 * ============================================================
 *  Roblox AI MCP Server
 *  让任意 MCP 客户端（Claude/类似软件）通过工具调用 Roblox
 *  ============================================================
 *  架构：
 *    MCP Client (AI)  <==stdio==>  本服务  <==WebSocket(127.0.0.1:9339)==>  Bridge Server
 *    Bridge Server    <==WebSocket==>  Roblox 执行器 (Luau client.lua)
 *    Bridge Server    <==HTTP/WS==>    GUI (index.html)
 *
 *  运行：
 *    node mcp-server.js
 *  或注册为 MCP 服务（MCP 客户端配置里）：
 *    node /path/to/mcp-server.js
 *
 *  全局配置（通过工具 set_bridge_target 修改）：
 *    bridge.host / bridge.port : Bridge Server 地址
 * ============================================================
 */
"use strict";

const { spawn } = require("child_process");
const http = require("http");
const WebSocket = require("ws");

const SDK_LIB_PATH = process.env.ROBLOX_MCP_SDK_LIB || "./node_modules/@modelcontextprotocol/sdk";
const LOG = (...a) => console.error("[McpRoblox]", ...a);

/* ===================== 配置 ===================== */
const DEFAULT_CONFIG = {
  bridge: { host: "127.0.0.1", port: 9339 },
};

/* ===================== Bridge 客户端 ===================== */
class BridgeClient {
  constructor(getConfig) {
    this.getConfig = getConfig;
    this.ws = null;
    this.reqSeq = 0;
    this.pending = new Map();   // seq -> {resolve,reject,timer}
    this.listeners = new Map(); // event -> [fn,...]
    this.connected = false;
  }

  _url() {
    const { host, port } = this.getConfig().bridge;
    return `ws://${host}:${port}/ws`;
  }

  connect() {
    const url = this._url();
    LOG(`connecting to bridge ${url} ...`);
    this.ws = new WebSocket(url);
    this.ws.on("open", () => {
      this.connected = true;
      LOG("bridge connected ✓");
      this._emit("_open");
    });
    this.ws.on("message", (data) => {
      let msg;
      try { msg = JSON.parse(data.toString()); } catch { return; }
      if (msg && msg.type === "response" && msg.id != null) {
        const p = this.pending.get(msg.id);
        if (!p) return;
        this.pending.delete(msg.id);
        clearTimeout(p.timer);
        if (msg.ok) p.resolve(msg.data); else p.reject(new Error(msg.error || "bridge error"));
      } else if (msg && (msg.type === "event" || msg.type === "error")) {
        if (msg.type === "error") LOG("bridge error event:", msg.error);
        this._emit(msg.event || "error", msg);
      }
    });
    this.ws.on("close", () => {
      this.connected = false;
      LOG("bridge disconnected, retrying in 3s ...");
      this.pending.forEach((p) => { clearTimeout(p.timer); p.reject(new Error("bridge closed")); });
      this.pending.clear();
      this._emit("_close");
      setTimeout(() => this.connect(), 3000);
    });
    this.ws.on("error", (e) => LOG("ws error:", e.message));
  }

  _emit(ev, payload) {
    (this.listeners.get(ev) || []).forEach((fn) => {
      try { fn(payload); } catch (e) { LOG("listener error:", e); }
    });
  }

  on(ev, fn) {
    if (!this.listeners.has(ev)) this.listeners.set(ev, []);
    this.listeners.get(ev).push(fn);
  }

  request(method, params = {}, timeout = 15000) {
    return new Promise((resolve, reject) => {
      if (!this.connected) { reject(new Error("桥接服务未连接，请先启动 bridge-server.js")); return; }
      const seq = ++this.reqSeq;
      const timer = setTimeout(() => {
        this.pending.delete(seq);
        reject(new Error(`请求超时(${method})`));
      }, timeout);
      this.pending.set(seq, { resolve, reject, timer });
      this.ws.send(JSON.stringify({ id: seq, method, params }));
    });
  }
}

/* ===================== MCP 工具仓库 ===================== */
function defineTools(server, bridge, getConfig) {
  const tools = {
    list: () => [
      { name: "bridge_status", description: "查看桥接服务连接状态（是否已连上 Roblox）" },
      { name: "set_bridge_target", description: "修改桥接服务地址（host+port），修改后自动重连", inputSchema: { host: "string", port: "number" } },
      { name: "scan_game", description: "深度扫描游戏环境，返回玩家、NPC、实体、可交互对象、金币/背包、枪械等", inputSchema: { scope: "string?(self|world|all)" } },
      { name: "get_self", description: "获取自己角色的当前位置、血量、速度、装备、状态" },
      { name: "get_players", description: "获取所有玩家列表（名字/团队/血量/距离/是否在视野）" },
      { name: "get_entities", description: "获取可被脚本识别的实体（NPC/敌人/掉落物/资源节点）" },
      { name: "get_inventory", description: "获取自己的背包/金币/装备列表" },
      { name: "find_object", description: "按名称/类搜索游戏对象", inputSchema: { name: "string", className: "string?", deep: "boolean?" } },
      { name: "get_workspace_tree", description: "返回 Workspace 结构树（用于理解游戏逻辑）", inputSchema: { maxDepth: "number?" } },
      { name: "send_notification", description: "在游戏内屏幕弹一条消息通知", inputSchema: { text: "string" } },
      { name: "teleport", description: "传送角色（如无权限返回错误，可配 Noclip/Anticheat 绕过策略）", inputSchema: { x: "number", y: "number", z: "number" } },
      { name: "give_items", description: "给背包添加物品（本地注入玩法）", inputSchema: { item_name: "string", amount: "number?" } },
      { name: "modify_stat", description: "修改本地属性（血量/金币/速度等 需游戏原生机制支持）", inputSchema: { stat: "string", value: "number" } },
      { name: "attack_target", description: "自动攻击指定玩家/NPC", inputSchema: { target: "string" } },
      { name: "exec_lua", description: "向 Roblox 执行任意 Luau 代码（最终手段，AI 自由发挥）", inputSchema: { code: "string" } },
    ],
    call: async (name, args = {}) => {
      switch (name) {
        case "bridge_status": {
          const st = await bridge.request("status", {}, 4000).catch((e) => ({ error: e.message }));
          return { connected: bridge.connected, roblox: st };
        }
        case "set_bridge_target": {
          const cfg = getConfig();
          cfg.bridge.host = String(args.host || cfg.bridge.host);
          cfg.bridge.port = Number(args.port || cfg.bridge.port);
          bridge.ws && bridge.ws.close();
          bridge.connect();
          return { ok: true, target: cfg.bridge };
        }
        case "scan_game": return bridge.request("scan_game", args);
        case "get_self": return bridge.request("get_self", args);
        case "get_players": return bridge.request("get_players", args);
        case "get_entities": return bridge.request("get_entities", args);
        case "get_inventory": return bridge.request("get_inventory", args);
        case "find_object": return bridge.request("find_object", args);
        case "get_workspace_tree": return bridge.request("get_workspace_tree", args);
        case "send_notification": return bridge.request("send_notification", args);
        case "teleport": return bridge.request("teleport", args);
        case "give_items": return bridge.request("give_items", args);
        case "modify_stat": return bridge.request("modify_stat", args);
        case "attack_target": return bridge.request("attack_target", args);
        case "exec_lua": return bridge.request("exec_lua", args);
        default: throw new Error(`未知工具: ${name}`);
      }
    },
  };
  return tools;
}

/* ===================== 启动 ===================== */
async function main() {
  const config = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
  const configFile = process.env.ROBLOX_MCP_CONFIG || "./mcp-config.json";
  try {
    Object.assign(config, JSON.parse(require("fs").readFileSync(configFile, "utf8")));
  } catch {}

  let mcp;
  try {
    const sdk = require(SDK_LIB_PATH);
    mcp = new sdk.Server(
      { name: "roblox-mcp", version: "1.0.0" },
      { capabilities: { tools: {} } }
    );
  } catch (e) {
    LOG("无法加载 MCP SDK:", e.message);
    LOG("请先执行: cd <本目录> && npm install @modelcontextprotocol/sdk ws");
    process.exit(1);
  }

  const bridge = new BridgeClient(() => config);
  bridge.connect();

  const tools = defineTools(serverPlaceholder(), bridge, () => config);
  mcp.setRequestHandler(sdk.ListToolsRequestSchema, async () => ({ tools: tools.list() }));
  mcp.setRequestHandler(sdk.CallToolRequestSchema, async (req) => {
    const t = req.params.name;
    const args = req.params.arguments || {};
    LOG("tool call:", t, JSON.stringify(args).slice(0, 200));
    try {
      const res = await tools.call(t, args);
      return { content: [{ type: "text", text: JSON.stringify(res, null, 2) }] };
    } catch (e) {
      return { content: [{ type: "text", text: `错误: ${e.message}` }], isError: true };
    }
  });

  const stdio = new sdk.StdioServerTransport();
  await mcp.connect(stdio);
  LOG("Roblox MCP Server running (stdio) ✓  工具数:", tools.list().length);

  // 无依赖时也能单独跑一个 HTTP 诊断端口
  http.createServer((req, res) => {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({
      ok: true,
      bridgeConnected: bridge.connected,
      tools: tools.list().map((t) => t.name),
      hint: "我是 MCP Server，请通过 MCP 客户端调用工具"
    }));
  }).listen(9340, () => LOG("diagnostic http on :9340"));
}

function serverPlaceholder() { return {}; } // defineTools 里不需要 server 实例，仅占位

main().catch((e) => { LOG("fatal:", e); process.exit(1); });