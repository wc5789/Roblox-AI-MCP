# 🤖 Roblox AI MCP — 全自动外挂系统

**AI 自动扫描游戏内容 → 分析 → 生成并执行修改脚本**，支持 PC + 移动端，鼠标 + 触摸全兼容。

---

## 📦 项目结构

```
roblox_ai_mcp/
├── bridge-server.js      # 桥接中转服务（Roblox ⇄ MCP ⇄ GUI）
├── mcp-server.js         # MCP Server（给 AI 提供工具调用）
├── client.lua            # Roblox 执行器脚本（Luau 扫描+执行）
├── package.json          # 依赖配置
├── gui/
│   └── index.html        # 跨平台 GUI 控制面板
└── templates/            # 预留模板目录
```

## 🔗 架构图

```
┌────────────┐    stdio     ┌──────────────┐    WS    ┌──────────────┐
│  AI 客户端  │ <──────────> │ mcp-server.js │ <──────> │ bridge-server │
│(Claude等MCP)│              └──────────────┘          └──────┬───────┘
└────────────┘                                                  │ WS
                                                    ┌───────────┴───────────┐
                                                    │ GUI (浏览器/手机)      │
                                                    │ Roblox 执行器(client.lua)│
                                                    └───────────────────────┘
```

## 🚀 快速开始

### 1. 安装依赖（电脑端）
```bash
cd roblox_ai_mcp
npm install
```

### 2. 启动桥接服务
```bash
node bridge-server.js
# 默认端口 9339
```

### 3. 启动 MCP Server
```bash
node mcp-server.js
# stdio 模式运行，自动连接 bridge
```

### 4. 配置 AI 客户端 MCP
在支持 MCP 的 AI 客户端（Claude Desktop / Cursor / 自定义软件等）里添加 MCP 服务：
```json
{
  "mcpServers": {
    "roblox": {
      "command": "node",
      "args": ["/绝对路径/roblox_ai_mcp/mcp-server.js"],
      "env": {
        "ROBLOX_MCP_SDK_LIB": "/绝对路径/roblox_ai_mcp/node_modules/@modelcontextprotocol/sdk"
      }
    }
  }
}
```

### 5. 加载 Roblox 执行器脚本
1. 启动任意 Roblox 执行器（PC 端或移动端均可）
2. 打开任意 Roblox 游戏
3. 将 `client.lua` 内容粘贴到执行器运行
4. 修改 `CONFIG.wsUrl` 为你的桥接服务地址：
   - 本机运行：`ws://127.0.0.1:9339/ws/roblox`
   - 手机连电脑局域网：`ws://<电脑IP>:9339/ws/roblox`
   - 手机端注意：需要同 WiFi 且关闭防火墙

### 6. 打开 GUI
浏览器访问：`http://localhost:9339/`
或在手机浏览器访问：`http://<电脑IP>:9339/`

## 🛠 MCP 工具列表

| 工具 | 说明 |
|------|------|
| `bridge_status` | 查看桥接连接状态 |
| `set_bridge_target` | 修改桥接服务器地址 |
| `scan_game` | 深度扫描游戏环境（玩家/实体/背包/自身状态） |
| `get_self` | 获取自身属性 |
| `get_players` | 获取所有玩家 |
| `get_entities` | 获取实体（NPC/掉落物等） |
| `get_inventory` | 获取背包 |
| `find_object` | 按名称/类搜索对象 |
| `get_workspace_tree` | 获取 Workspace 结构树 |
| `send_notification` | 游戏内弹窗通知 |
| `teleport` | 传送 |
| `give_items` | 给物品 |
| `modify_stat` | 修改属性 |
| `attack_target` | 自动攻击 |
| `exec_lua` | 执行任意 Luau 代码 |

## 💬 给 AI 的提示词示例

```
扫描当前游戏环境并告诉我有哪些玩家、物品和实体
```

```
把我的血量改成满血，速度加成2倍
```

```
传送到最近的敌人身边
```

```
查找所有 Tool 类对象
```

## ⚠️ 注意事项

- **仅供学习研究**，请遵守游戏服务条款
- 使用执行器有封号风险，请自行评估
- `modify_stat` / `give_items` 等需游戏原生机制支持，幂等性取决于游戏
- 移动端执行器和电脑端协议可能不同，需适配

## 📱 移动端支持

- GUI 自动适配触摸滑动（`touch-action: manipulation`）
- 手机浏览器访问 GUI 即可控制
- Roblox 移动端执行器需支持 `HttpService:WebSocketAsync` 才能连接

---
Made with ❤️ 蓝色大肥鱼 for 主人