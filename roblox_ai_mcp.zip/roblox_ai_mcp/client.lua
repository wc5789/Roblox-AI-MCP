--[[
============================================================
  Roblox AI MCP - 游戏内聊天GUI + Operit MCP 对接
============================================================
  在游戏内创建一个聊天界面 (ScreenGui)，输入提示词后：
  1. 自动扫描游戏内容
  2. 发送给 Operit MCP AI 分析
  3. AI 自动调用工具修改游戏
  4. 结果回显在聊天框内
  支持鼠标 + 触摸，F2 或悬浮球打开
============================================================
]]--

-- ========== 配置 ==========
local CONFIG = {
    wsUrl   = "ws://127.0.0.1:9339/ws/roblox",
    reconnectDelay = 3,
    openKey  = Enum.KeyCode.F2,
    maxChatMsgs = 60,
    autoScanBeforeChat = true,
}

-- ========== 服务 ==========
local H = game:GetService("HttpService")
local P = game:GetService("Players")
local T = game:GetService("TweenService")
local UIS = game:GetService("UserInputService")
local CG = game:GetService("CoreGui")

local plr = P.LocalPlayer
assert(plr, "请确保在 Roblox 游戏内执行")

-- ========== 状态 ==========
local ws, connected = nil, false
local chatMsgs = {}
local seqCount = 0
local pending = {}
local guiVisible = false
local gui, bg, chatFrame, msgList, inputBox, floatBtn = nil, nil, nil, nil, nil, nil

-- ========== 工具函数 ==========
local function safe(f) local o,r=pcall(f); return o,r end
local function e(d) return H:JSONEncode(d) end
local function d(r) return H:JSONDecode(r) end
local function getRoot(c) return c and (c:FindFirstChild("HumanoidRootPart") or c:FindFirstChild("Torso")) end
local function posTo(p) return p and {x=p.X,y=p.Y,z=p.Z} end
local function getPath(i)
    local p={};local c=i
    while c and c~=game do table.insert(p,1,c.Name);c=c.Parent end
    return table.concat(p,".")
end

-- ========== 扫描引擎 ==========
local ENTITY_KW = {"npc","enemy","monster","zombie","boss","guard",
    "coin","cash","money","gem","loot","chest","ore","node","pet","sword","gun"}
local function bfs(root,depth,fn)
    local r,q={},{{n=root,d=0}}
    while #q>0 do
        local it=table.remove(q,1);local n,d=it.n,it.d
        if d>0 and fn(n,d) then table.insert(r,n) end
        if d>=depth then continue end
        for _,c in ipairs(n:GetChildren()) do table.insert(q,{n=c,d=d+1}) end
    end
    return r
end
local function sh(h)
    if not h then return nil end
    return {health=h.Health,maxHealth=h.MaxHealth,walkSpeed=h.WalkSpeed}
end
local function getSelf()
    local c=plr.Character;local hrp=getRoot(c);local h=c and c:FindFirstChildOfClass("Humanoid")
    local ls=plr:FindFirstChild("leaderstats");local s={}
    if ls then for _,v in ipairs(ls:GetChildren()) do if v:IsA("ValueBase") then s[v.Name]=v.Value end end end
    return {name=plr.Name,displayName=plr.DisplayName,userId=plr.UserId,
        position=posTo(hrp and hrp.Position),humanoid=sh(h),leaderstats=s,
        team=plr.Team and plr.Team.Name,gameName=game.Name,placeId=game.PlaceId}
end
local function getPlayers()
    local r={}
    for _,p in ipairs(P:GetPlayers()) do if p~=plr then
        local c=p.Character;local hrp=getRoot(c);local h=c and c:FindFirstChildOfClass("Humanoid")
        if hrp then
            local mr=getRoot(plr.Character)
            table.insert(r,{name=p.Name,position=posTo(hrp.Position),
                health=h and h.Health,distance=mr and math.round((mr.Position-hrp.Position).Magnitude),
                team=p.Team and p.Team.Name})
        end
    end end
    return r
end
local function getEnts(maxC)
    maxC=maxC or 40;local r,c={},0
    for _,inst in ipairs(bfs(workspace,8,function(n,d)
        if n:IsA("Humanoid") and n.Parent~=plr.Character then return true end
        local nl=string.lower(n.Name or "")
        for _,kw in ipairs(ENTITY_KW) do if string.find(nl,kw,1,true) then return true end end
        return false
    end)) do
        if c>=maxC then break end
        local info={name=inst.Name,className=inst.ClassName,path=getPath(inst)}
        if inst:IsA("BasePart") and inst.Position then info.position=posTo(inst.Position) end
        table.insert(r,info);c=c+1
    end
    return r
end
local function getInv()
    local items={}
    for _,o in ipairs(plr.Backpack:GetChildren()) do table.insert(items,{name=o.Name,className=o.ClassName}) end
    local c=plr.Character
    if c then for _,o in ipairs(c:GetChildren()) do if o:IsA("Tool") then table.insert(items,{name=o.Name,className="Tool",equipped=true}) end end end
    return items
end
local function scanAll()
    return {self=getSelf(),players=getPlayers(),entities=getEnts(40),
        inventory=getInv(),game={name=game.Name,placeId=game.PlaceId}}
end

-- ========== 动作执行 ==========
local function doTP(x,y,z)
    local hrp=getRoot(plr.Character)
    if not hrp then return {ok=false,error="角色不存在"} end
    hrp.CFrame=CFrame.new(x,y,z)
    safe(function()local cam=workspace.CurrentCamera;if cam then cam.CFrame=cam.CFrame+(CFrame.new(x,y,z).Position-cam.Position)end end)
    return {ok=true,position={x=x,y=y,z=z}}
end
local function doMod(stat,value)
    local c=plr.Character;local h=c and c:FindFirstChildOfClass("Humanoid");local ch={};local sl=string.lower(stat)
    if h then
        if sl=="health"or sl=="hp" then h.Health=value;table.insert(ch,"health")
        elseif sl=="walkspeed"or sl=="speed" then h.WalkSpeed=value;table.insert(ch,"walkspeed")
        elseif sl=="jumppower" then h.JumpPower=value;table.insert(ch,"jumppower")end
    end
    local ls=plr:FindFirstChild("leaderstats")
    if ls then for _,v in ipairs(ls:GetChildren()) do
        if(v:IsA("IntValue")or v:IsA("NumberValue"))and string.lower(v.Name)==sl then v.Value=value;table.insert(ch,v.Name)end
    end end
    return {ok=#ch>0,changed=ch}
end
local function doGive(n,amt)
    amt=amt or 1
    for i=1,amt do local t=Instance.new("Tool");t.Name=n;t.Parent=plr.Backpack end
    return {ok=true,item=n,amount=amt}
end
local function doAtk(target)
    local tc=P:FindFirstChild(target)and P:FindFirstChild(target).Character
    if not tc then return {ok=false,error="找不到目标: "..target} end
    local tr=getRoot(tc);local mr=getRoot(plr.Character)
    if not tr or not mr then return {ok=false,error="角色不完整"} end
    mr.CFrame=CFrame.lookAt(mr.Position,tr.Position)
    local c=plr.Character
    if c then for _,o in ipairs(c:GetChildren()) do if o:IsA("Tool") then
        safe(function()o:Activate()
            for _,n in ipairs({"Attack","Click","Hit","Damage","Melee"})do
                local r=c:FindFirstChild(n,true)or o:FindFirstChild(n,true)
                if r and r:IsA("RemoteEvent")then r:FireServer({Tool=o})end
            end
        end);break
    end end end
    return {ok=true,target=target,distance=math.round((mr.Position-tr.Position).Magnitude)}
end
local function doLua(code)
    local fn,err=loadstring(code)
    if not fn then return {ok=false,error="编译错误: "..tostring(err)} end
    local ok,r=pcall(fn)
    return {ok=ok,output=ok and tostring(r),error=not ok and tostring(r)}
end
local function doNotify(text)
    local sg=Instance.new("ScreenGui");sg.Name="McpNotif";sg.ResetOnSpawn=false;sg.IgnoreGuiInset=true
    sg.Parent=plr:FindFirstChildOfClass("PlayerGui")or plr.PlayerGui
    local f=Instance.new("Frame");f.Size=UDim2.fromOffset(320,56);f.Position=UDim2.new(0.5,-160,0.1,0)
    f.BackgroundColor3=Color3.fromRGB(10,15,30);f.BackgroundTransparency=0.15;f.BorderSizePixel=0;f.Parent=sg
    local cr=Instance.new("UICorner");cr.CornerRadius=UDim.new(0,12);cr.Parent=f
    local l=Instance.new("TextLabel");l.Size=UDim2.fromScale(1,1);l.BackgroundTransparency=1
    l.Text=text;l.TextColor3=Color3.fromRGB(255,255,255);l.TextSize=15;l.Font=Enum.Font.Gotham;l.TextWrapped=true;l.Parent=f
    task.spawn(function()task.wait(3)
        local tw=T:Create(f,TweenInfo.new(0.4),{BackgroundTransparency=1})
        local tw2=T:Create(l,TweenInfo.new(0.4),{TextTransparency=1})
        tw:Play();tw2:Play();task.wait(0.5);sg:Destroy()
    end)
    return{ok=true}
end

-- ========== 命令分发 ==========
local function dispatch(msg)
    local m=msg.method;local p=msg.params or{};local r
    if m=="ping"then r={pong=true}
    elseif m=="status"then r={connected=true,playerName=plr.Name,gameName=game.Name}
    elseif m=="scan_game"then r=scanAll()
    elseif m=="get_self"then r=getSelf()
    elseif m=="get_players"then r=getPlayers()
    elseif m=="get_entities"then r=getEnts(40)
    elseif m=="get_inventory"then r=getInv()
    elseif m=="teleport"then r=doTP(p.x,p.y,p.z)
    elseif m=="modify_stat"then r=doMod(p.stat,p.value)
    elseif m=="give_items"then r=doGive(p.item_name,p.amount)
    elseif m=="attack_target"then r=doAtk(p.target)
    elseif m=="send_notification"then r=doNotify(p.text or "Hello!")
    elseif m=="exec_lua"then r=doLua(p.code)
    else r={ok=false,error="未知命令:"..tostring(m)}end
    if ws and connected then safe(function()ws:Send(e({type="response",id=msg.id,ok=r.ok or r.ok==nil,data=r}))end)end
end

-- ========== 执行AI动作 ==========
local function execAction(a)
    if not a or not a.type then return end
    local r
    if a.type=="teleport"then r=doTP(a.x or 0,a.y or 50,a.z or 0)
    elseif a.type=="modify_stat"or a.type=="modify"then r=doMod(a.stat or a.name,a.value)
    elseif a.type=="give_items"or a.type=="give"then r=doGive(a.item_name or a.name,a.amount or 1)
    elseif a.type=="attack"then r=doAtk(a.target)
    elseif a.type=="exec_lua"or a.type=="lua"then r=doLua(a.code)
    elseif a.type=="notify"then r=doNotify(a.text or "AI MCP");r={ok=true}
    else r={ok=false,error="未知动作:"..a.type}end
    local st=r.ok and"✅"or"❌"
    local dt=r.ok and(r.position and string.format("传送至 %.0f,%.0f,%.0f",r.position.x,r.position.y,r.position.z)or r.changed and"修改了 "..table.concat(r.changed,", ")or r.item and"给了 "..r.item or r.target and"攻击了 "..r.target or"")or r.error or""
    addChatMsg("⚡ 动作",st.." "..dt,r.ok and Color3.fromRGB(0,255,120)or Color3.fromRGB(255,80,80))
end

-- ========== WebSocket ==========
local function connectWS()
    if ws then safe(function()ws:Close()end);ws=nil end
    connected=false
    local ok,sock=pcall(function()return H:WebSocketAsync(CONFIG.wsUrl,"roblox")end)
    if not ok or not sock then ws=nil;task.wait(CONFIG.reconnectDelay);return end
    ws=sock;connected=true
    addChatMsg("系统","🟢 AI MCP 连接成功！",Color3.fromRGB(0,255,120))
    -- 发送连接信息
    safe(function()ws:Send(e({type:"connected",playerName=plr.Name,gameName=game.Name,placeId=game.PlaceId}))end)
    ws.OnMessage:Connect(function(raw)
        local msg;ok,msg=pcall(d,raw)
        if not ok or not msg then return end
        if msg.type=="command"then task.spawn(function()dispatch(msg)end)
        elseif msg.type=="response"and msg.id then
            local pp=pending[msg.id]
            if pp then
                if pp.t then pp.t:cancel()end
                pending[msg.id]=nil
                if msg.ok then pp.r(msg.data)else pp.j(msg.error or"未知错误")end
            end
        elseif msg.type=="chat_response"then
            addChatMsg("AI 🤖",msg.text or"分析完成",Color3.fromRGB(0,200,255))
            if msg.actions then
                for _,a in ipairs(msg.actions)do
                    task.spawn(function()execAction(a)end)
                    task.wait(0.3)
                end
            end
            if msg.summary then addChatMsg("📋 总结",msg.summary,Color3.fromRGB(200,200,100))end
        elseif msg.type=="chat_error"then
            addChatMsg("系统","❌ "..(msg.error or"未知错误"),Color3.fromRGB(255,80,80))
        end
    end)
    ws.OnClose:Connect(function()
        connected=false;ws=nil
        addChatMsg("系统","🔴 AI MCP 断开连接",Color3.fromRGB(255,80,80))
    end)
end

-- ========== 发送聊天查询 ==========
local function sendQuery(text)
    if not connected then addChatMsg("系统","❌ 未连接，请先启动桥接服务",Color3.fromRGB(255,80,80));return end
    if text==nil or text==""then return end
    addChatMsg("你",text,Color3.fromRGB(255,255,255))
    inputBox.Text=""
    if CONFIG.autoScanBeforeChat then
        addChatMsg("系统","🔍 正在扫描游戏环境...",Color3.fromRGB(200,200,100))
        local sd=scanAll()
        addChatMsg("系统",string.format("✅ 扫描完成！%d玩家,%d实体,%d物品",#sd.players,#sd.entities,#sd.inventory),Color3.fromRGB(100,200,100))
        addChatMsg("系统","⏳ 等待 Operit AI 分析...",Color3.fromRGB(200,200,100))
        safe(function()ws:Send(e({type:"chat_query",text=text,scan=sd,player=plr.Name,game=game.Name}))end)
    else
        safe(function()ws:Send(e({type:"chat_query",text=text,player=plr.Name,game=game.Name}))end)
    end
end

-- ========== 聊天GUI ==========
local function addChatMsg(who,text,color)
    color=color or Color3.fromRGB(200,200,200)
    table.insert(chatMsgs,{who=who,text=text,color=color})
    if #chatMsgs>CONFIG.maxChatMsgs then table.remove(chatMsgs,1)end
    if msgList and guiVisible then renderMsgs()end
end

local function renderMsgs()
    if not msgList then return end
    for _,v in ipairs(msgList:GetChildren())do if v:IsA("Frame")then v:Destroy()end end
    for _,msg in ipairs(chatMsgs)do
        local f=Instance.new("Frame");f.Size=UDim2.new(1,-8,0,0)
        f.BackgroundTransparency=1;f.BorderSizePixel=0;f.Parent=msgList
        local who=Instance.new("TextLabel")
        who.Size=UDim2.new(0,0,0,18);who.Position=UDim2.new(0,4,0,2)
        who.BackgroundTransparency=1;who.Text=msg.who..":";who.TextColor3=msg.color
        who.TextSize=13;who.Font=Enum.Font.GothamBold;who.TextXAlignment=Enum.TextXAlignment.Left
        who.AutomaticSize=Enum.AutomaticSize.XY;who.Parent=f
        local txt=Instance.new("TextLabel")
        txt.Size=UDim2.new(1,-8,0,0);txt.Position=UDim2.new(0,4,0,20)
        txt.BackgroundTransparency=1;txt.Text=msg.text;txt.TextColor3=Color3.fromRGB(230,230,230)
        txt.TextSize=14;txt.Font=Enum.Font.Gotham;txt.TextXAlignment=Enum.TextXAlignment.Left
        txt.TextWrapped=true;txt.RichText=true;txt.AutomaticSize=Enum.AutomaticSize.Y;txt.Parent=f
        f.AutomaticSize=Enum.AutomaticSize.Y
    end
    task.wait()
    if msgList then msgList.CanvasPosition=Vector2.new(0,msgList.AbsoluteCanvasSize.Y)end
end

local function sendBtnClick()
    local t=inputBox and inputBox.Text:match("^%s*(.-)%s*$")or""
    if t~=""then sendQuery(t)end
end

local function toggleGUI(show)
    if show==nil then show=not guiVisible end
    guiVisible=show
    if bg then bg.Visible=show end
    if floatBtn then floatBtn.Visible=not show end
    if show and msgList then renderMsgs()end
end

local function createGUI()
    local sg=Instance.new("ScreenGui")
    sg.Name="McpChatGUI";sg.ResetOnSpawn=false;sg.ZIndexBehavior=Enum.ZIndexBehavior.Sibling
    sg.IgnoreGuiInset=true;sg.DisplayOrder=999
    local parented=false
    for _,c in ipairs({CG,plr:FindFirstChildOfClass("PlayerGui"),plr.PlayerGui})do
        if c then sg.Parent=c;parented=true;break end
    end
    if not parented then plr:WaitForChild("PlayerGui");sg.Parent=plr.PlayerGui end
    gui=sg

    -- 背景遮罩
    bg=Instance.new("Frame")
    bg.Name="Bg";bg.Size=UDim2.fromScale(1,1);bg.BackgroundColor3=Color3.fromRGB(0,0,0)
    bg.BackgroundTransparency=0.55;bg.Visible=false;bg.Active=true;bg.Parent=sg
    bg.InputBegan:Connect(function(i)
        if i.UserInputType==Enum.UserInputType.Touch or i.UserInputType==Enum.UserInputType.MouseButton1 then toggleGUI(false)end
    end)

    -- 聊天窗口
    chatFrame=Instance.new("Frame")
    chatFrame.Name="ChatWindow"
    local vs=workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize or Vector2.new(500,500)
    local w=math.min(420,vs.X*0.88);local h=math.min(500,vs.Y*0.78)
    chatFrame.Size=UDim2.fromOffset(w,h)
    chatFrame.Position=UDim2.new(0.5,-w/2,0.5,-h/2)
    chatFrame.BackgroundColor3=Color3.fromRGB(8,12,24);chatFrame.BackgroundTransparency=0.06
    chatFrame.BorderSizePixel=0;chatFrame.Active=true;chatFrame.Parent=bg
    local cr=Instance.new("UICorner");cr.CornerRadius=UDim.new(0,16);cr.Parent=chatFrame
    local st=Instance.new("UIStroke");st.Thickness=1.5;st.Color=Color3.fromRGB(0,130,255);st.Transparency=0.5;st.Parent=chatFrame

    -- 标题栏
    local tb=Instance.new("Frame")
    tb.Size=UDim2.new(1,0,0,38);tb.BackgroundColor3=Color3.fromRGB(0,70,170);tb.BackgroundTransparency=0.2;tb.BorderSizePixel=0;tb.Parent=chatFrame
    local tc=Instance.new("UICorner");tc.CornerRadius=UDim.new(0,16);tc.Parent=tb
    local tfill=Instance.new("Frame");tfill.Size=UDim2.new(1,0,0,18);tfill.Position=UDim2.new(0,0,0,18)
    tfill.BackgroundColor3=Color3.fromRGB(0,70,170);tfill.BackgroundTransparency=0.2;tfill.BorderSizePixel=0;tfill.Parent=tb
    local tl=Instance.new("TextLabel")
    tl.Size=UDim2.new(1,-40,1,0);tl.BackgroundTransparency=1
    tl.Text="🤖 AI MCP · 聊天助手";tl.TextColor3=Color3.fromRGB(255,255,255);tl.TextSize=15;tl.Font=Enum.Font.GothamBold
    tl.TextXAlignment=Enum.TextXAlignment.Left;tl.Position=UDim2.new(0,14,0,0);tl.Parent=tb

    -- 关闭按钮
    local cb=Instance.new("TextButton")
    cb.Size=UDim2.fromOffset(32,32);cb.Position=UDim2.new(1,-36,0,3)
    cb.BackgroundTransparency=1;cb.Text="✕";cb.TextColor3=Color3.fromRGB(255,255,255)
    cb.TextSize=18;cb.Font=Enum.Font.GothamBold;cb.Parent=tb
    cb.MouseButton1Click:Connect(function()toggleGUI(false)end)
    cb.InputBegan:Connect(function(i)if i.UserInputType==Enum.UserInputType.Touch then toggleGUI(false)end end)

    -- 拖动
    local drag,ds,sp=false,nil,nil
    tb.InputBegan:Connect(function(i)
        if i.UserInputType==Enum.UserInputType.MouseButton1 or i.UserInputType==Enum.UserInputType.Touch then
            drag=true;ds=i.Position;sp=chatFrame.Position
            i.Changed:Connect(function()if i.UserInputState==Enum.UserInputState.End then drag=false end end)
        end
    end)
    UIS.InputChanged:Connect(function(i)
        if drag and(i.UserInputType==Enum.UserInputType.MouseMovement or i.UserInputType==Enum.UserInputType.Touch)then
            local delta=i.Position-ds
            chatFrame.Position=UDim2.new(0,sp.X.Offset+delta.X,0,sp.Y.Offset+delta.Y)
        end
    end)

    -- 消息列表
    msgList=Instance.new("ScrollingFrame")
    msgList.Name="MsgList"
    msgList.Size=UDim2.new(1,-12,1,-100)
    msgList.Position=UDim2.new(0,6,0,44)
    msgList.BackgroundTransparency=1;msgList.BorderSizePixel=0
    msgList.ScrollBarThickness=4;msgList.ScrollBarImageColor3=Color3.fromRGB(0,130,255)
    msgList.CanvasSize=UDim2.new(0,0,0,0);msgList.AutomaticCanvasSize=Enum.AutomaticSize.Y
    msgList.ScrollingDirection=Enum.ScrollingDirection.Y;msgList.Parent=chatFrame
    local lay=Instance.new("UIListLayout");lay.Padding=UDim.new(0,4);lay.HorizontalAlignment=Enum.HorizontalAlignment.Left
    lay.SortOrder=Enum.SortOrder.LayoutOrder;lay.Parent=msgList

    -- 输入框
    local ibg=Instance.new("Frame")
    ibg.Size=UDim2.new(1,-12,0,44);ibg.Position=UDim2.new(0,6,1,-50)
    ibg.BackgroundColor3=Color3.fromRGB(20,28,48);ibg.BackgroundTransparency=0.2;ibg.BorderSizePixel=0;ibg.Parent=chatFrame
    local icr=Instance.new("UICorner");icr.CornerRadius=UDim.new(0,12);icr.Parent=ibg
    inputBox=Instance.new("TextBox")
    inputBox.Size=UDim2.new(1,-52,1,0);inputBox.Position=UDim2.new(0,12,0,0)
    inputBox.BackgroundTransparency=1;inputBox.PlaceholderText="输入提示词，例如: 把我变成无敌..."
    inputBox.PlaceholderColor3=Color3.fromRGB(120,130,150);inputBox.Text=""
    inputBox.TextColor3=Color3.fromRGB(255,255,255);inputBox.TextSize=15;inputBox.Font=Enum.Font.Gotham
    inputBox.TextXAlignment=Enum.TextXAlignment.Left;inputBox.ClearTextOnFocus=false;inputBox.Parent=ibg
    inputBox.FocusLost:Connect(function(enter)if enter then sendBtnClick()end end)

    -- 发送按钮
    local sbtn=Instance.new("TextButton")
    sbtn.Size=UDim2.fromOffset(40,40);sbtn.Position=UDim2.new(1,-46,0,2)
    sbtn.BackgroundColor3=Color3.fromRGB(0,150,255);sbtn.BackgroundTransparency=0.2
    sbtn.Text="➤";sbtn.TextColor3=Color3.fromRGB(255,255,255);sbtn.TextSize=18;sbtn.Font=Enum.Font.GothamBold;sbtn.Parent=ibg
    local scr=Instance.new("UICorner");scr.CornerRadius=UDim.new(0,10);scr.Parent=sbtn
    sbtn.MouseButton1Click:Connect(sendBtnClick)
    sbtn.InputBegan:Connect(function(i)if i.UserInputType==Enum.UserInputType.Touch then sendBtnClick()end end)

    -- 悬浮球（聊天关闭时出现）
    floatBtn=Instance.new("TextButton")
    floatBtn.Name="FloatBtn"
    floatBtn.Size=UDim2.fromOffset(52,52)
    floatBtn.Position=UDim2.new(1,-64,1,-64)
    floatBtn.BackgroundColor3=Color3.fromRGB(0,100,220);floatBtn.BackgroundTransparency=0.15
    floatBtn.BorderSizePixel=0;floatBtn.Text="💬";floatBtn.TextSize=24;floatBtn.Font=Enum.Font.GothamBold;floatBtn.Parent=sg
    local fcr=Instance.new("UICorner");fcr.CornerRadius=UDim.new(0,26);fcr.Parent=floatBtn
    local fst=Instance.new("UIStroke");fst.Thickness=2;fst.Color=Color3.fromRGB(0,200,255);fst.Transparency=0.4;fst.Parent=floatBtn
    floatBtn.MouseButton1Click:Connect(function()toggleGUI(true)end)
    floatBtn.InputBegan:Connect(function(i)if i.UserInputType==Enum.UserInputType.Touch then toggleGUI(true)end end)

    -- 悬浮球拖动
    local fDrag,fDs,fSp=false,nil,nil
    floatBtn.InputBegan:Connect(function(i)
        if i.UserInputType==Enum.UserInputType.MouseButton1 or i.UserInputType==Enum.UserInputType.Touch then
            fDrag=true;fDs=i.Position;fSp=floatBtn.Position
            i.Changed:Connect(function()if i.UserInputState==Enum.UserInputState.End then fDrag=false end end)
        end
    end)
    UIS.InputChanged:Connect(function(i)
        if fDrag and(i.UserInputType==Enum.UserInputType.MouseMovement or i.UserInputType==Enum.UserInputType.Touch)then
            local delta=i.Position-fDs
            floatBtn.Position=UDim2.new(0,fSp.X.Offset+delta.X,0,fSp.Y.Offset+delta.Y)
        end
    end)
end

-- ========== 按键绑定 ==========
UIS.InputBegan:Connect(function(input, gp)
    if gp then return end
    if input.KeyCode==CONFIG.openKey then toggleGUI()end
end)

-- ========== 启动 ==========
createGUI()
addChatMsg("系统","🤖 AI MCP 聊天助手已加载",Color3.fromRGB(0,200,255))
addChatMsg("系统","按 F2 或点击悬浮球打开聊天界面",Color3.fromRGB(200,200,100))
addChatMsg("系统","正在连接 "..CONFIG.wsUrl.." ...",Color3.fromRGB(200,200,100))

-- 主循环（自动重连）
while true do
    if not connected then connectWS()end
    task.wait(CONFIG.reconnectDelay)
end