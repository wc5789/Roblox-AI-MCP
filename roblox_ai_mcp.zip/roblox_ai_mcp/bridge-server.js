#!/usr/bin/env node
/**
 * ============================================================
 *  Roblox AI MCP → Bridge Server (Operit 对接版)
 *  中间层：连接 Roblox 聊天GUI ↔ Operit MCP AI
 *  ============================================================
 *  路由：
 *    Roblox 执行器(client.lua) <==WS==> Bridge <==WS==> Operit MCP 插件
 *                                          <==HTTP==> GUI (网页版)
 *
 *  启动：
 *    node bridge-server.js [port=9339]
 *
 *  作为 Operit MCP 插件注册：
 *    在 Operit 的 MCP 配置中添加指向本服务的远程插件
 * ============================================================
 */
"use strict";

const http = require("http");
const url = require("url");
const fs = require("fs");
const path = require("path");
const WebSocket = require("ws");

const PORT = parseInt(process.argv[2] || process.env.BRIDGE_PORT || "9339", 10);
const LOG = (...a) => console.error(`[Bridge:${PORT}]`, ...a);

// ===================== 状态 =====================
const STATE = {
  robloxClients: new Map(),    // ws -> { id, playerName, gameName }
  guiClients: new Set(),
  mcpClients: new Set(),       // Operit MCP 连接
  pending: new Map(),
  seq: 0,
  lastScan: null,
  chatHistory: [],
  config: {
    autoReconnect: true,
    operitMcpUrl: null,        // 可选：Operit MCP 连接地址
  },
};

// ===================== HTTP 静态服务 =====================
const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript",
  ".css": "text/css",
  ".json": "application/json",
};

function serveStatic(req, res) {
  let p = url.parse(req.url).pathname;
  if (p === "/") p = "/index.html";
  const filePath = path.join(__dirname, "gui", p);
  if (!filePath.startsWith(path.join(__dirname, "gui"))) {
    res.writeHead(403); res.end("Forbidden"); return;
  }
  try {
    const data = fs.readFileSync(filePath);
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { "content-type": MIME[ext] || "application/octet-stream",
      "Access-Control-Allow-Origin": "*", "Cache-Control": "no-cache" });
    res.end(data);
  } catch {
    res.writeHead(404); res.end("Not Found");
  }
}

// ===================== 广播 =====================
function broadcast(msg, excludeWs = null) {
  const data = JSON.stringify(msg);
  STATE.guiClients.forEach((ws) => { if (ws !== excludeWs && ws.readyState === WebSocket.OPEN) ws.send(data); });
  STATE.mcpClients.forEach((ws) => { if (ws !== excludeWs && ws.readyState === WebSocket.OPEN) ws.send(data); });
  STATE.robloxClients.forEach((_, ws) => { if (ws !== excludeWs && ws.readyState === WebSocket.OPEN) ws.send(data); });
}

// ===================== Roblox → Operit MCP 转发 =====================
function forwardToOperit(robloxWs, msg) {
  // 如果有 Operit MCP 连接，转发给它
  if (STATE.mcpClients.size > 0) {
    const data = JSON.stringify({
      type: "chat_query",
      id: msg.id,
      text: msg.text,
      scan: msg.scan,
      player: msg.player,
      game: msg.game,
      source: "roblox",
    });
    STATE.mcpClients.forEach((ws) => {
      if (ws.readyState === WebSocket.OPEN) ws.send(data);
    });
    LOG("forwarded chat_query to Operit MCP");
    return true;
  }
  return false;
}

// ===================== 处理 Operit MCP 响应 =====================
function handleOperitResponse(msg) {
  // 转发给对应的 Roblox 客户端
  STATE.robloxClients.forEach((info, ws) => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: "chat_response",
        text: msg.text || msg.result || "分析完成",
        actions: msg.actions || msg.toolResults || [],
        summary: msg.summary,
      }));
    }
  });
  // 也转发给 GUI
  broadcast({ type: "chat_response", text: msg.text || msg.result, actions: msg.actions || [] });
}

// ===================== WebSocket 处理 =====================
function handleWS(ws, req, clientType) {
  const addr = req.socket.remoteAddress;
  LOG(`new ${clientType} client from ${addr}`);

  ws.on("message", (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (!msg || !msg.type) return;

    // 响应处理
    if (msg.type === "response" && msg.id != null) {
      const p = STATE.pending.get(msg.id);
      if (p) {
        STATE.pending.delete(msg.id);
        clearTimeout(p.timer);
        if (msg.ok) p.resolve(msg.data); else p.reject(new Error(msg.error || "error"));
      }
      return;
    }

    switch (msg.type) {
      // ===== 来自 Roblox 执行器 =====
      case "connected": {
        STATE.robloxClients.set(ws, { id: msg.id, playerName: msg.playerName || "未知", gameName: msg.gameName || "未知" });
        LOG("Roblox client connected:", msg.playerName, "@", msg.gameName);
        broadcast({ type: "status", robloxConnected: true, count: STATE.robloxClients.size });
        break;
      }
      case "scan_result": {
        STATE.lastScan = msg.data;
        broadcast({ type: "scan_result", data: msg.data });
        break;
      }
      case "chat_query": {
        // 收到聊天查询 → 转发给 Operit MCP
        LOG(`chat_query from ${msg.player}: "${(msg.text || "").slice(0, 50)}"`);
        STATE.chatHistory.push({ from: "roblox", player: msg.player, text: msg.text, time: Date.now() });
        if (STATE.chatHistory.length > 100) STATE.chatHistory.shift();

        const forwarded = forwardToOperit(ws, msg);
        if (!forwarded) {
          // 没有 Operit MCP 连接，直接回一个简单响应
          ws.send(JSON.stringify({
            type: "chat_response",
            id: msg.id,
            text: `已收到查询"${msg.text}"，但未检测到 Operit MCP 连接。请确保 Operit 已连接到此桥接服务。`,
            actions: [],
          }));
        }
        break;
      }
      case "log": { LOG("roblox log:", msg.text); break; }
      case "error": { LOG("roblox error:", msg.error); break; }

      // ===== 来自 Operit MCP 的响应 =====
      case "chat_response":
      case "ai_response": {
        LOG("Operit MCP response:", (msg.text || "").slice(0, 60));
        handleOperitResponse(msg);
        break;
      }

      // ===== 来自 GUI =====
      case "gui_command": {
        STATE.robloxClients.forEach((info, ws2) => {
          if (ws2.readyState === WebSocket.OPEN) {
            ws2.send(JSON.stringify({ type: "command", method: msg.method, params: msg.params || {} }));
          }
        });
        break;
      }
      case "ping": { ws.send(JSON.stringify({ type: "pong" })); break; }
      case "status_req": {
        ws.send(JSON.stringify({
          type: "status",
          robloxConnected: STATE.robloxClients.size > 0,
          robloxCount: STATE.robloxClients.size,
          mcpConnected: STATE.mcpClients.size > 0,
          mcpCount: STATE.mcpClients.size,
          chatHistory: STATE.chatHistory.slice(-10),
        }));
        break;
      }
      default: LOG("unknown message type:", msg.type);
    }
  });

  ws.on("close", () => {
    LOG(`${clientType} client disconnected`);
    if (clientType === "roblox") {
      STATE.robloxClients.delete(ws);
      broadcast({ type: "status", robloxConnected: STATE.robloxClients.size > 0, count: STATE.robloxClients.size });
    } else if (clientType === "gui") {
      STATE.guiClients.delete(ws);
    } else if (clientType === "mcp") {
      STATE.mcpClients.delete(ws);
      LOG("Operit MCP 断开，剩余:", STATE.mcpClients.size);
      broadcast({ type: "status", mcpConnected: false });
    }
  });

  ws.on("error", () => {});

  if (clientType === "gui") STATE.guiClients.add(ws);
  if (clientType === "mcp") STATE.mcpClients.add(ws);

  // 发送初始状态
  ws.send(JSON.stringify({
    type: "status",
    robloxConnected: STATE.robloxClients.size > 0,
    robloxCount: STATE.robloxClients.size,
    mcpConnected: STATE.mcpClients.size > 0,
    mcpCount: STATE.mcpClients.size,
    version: "1.0.0",
    instructions: "我是 Roblox-MCP Bridge。Operit 连接后，Roblox 的聊天查询会自动转发给你处理。请返回格式: { type: 'chat_response', text: '...', actions: [{type, ...}] }",
  }));
}

// ===================== 启动 HTTP + WebSocket =====================
const server = http.createServer(serveStatic);
const wss = new WebSocket.Server({ server });

wss.on("connection", (ws, req) => {
  const u = url.parse(req.url, true).pathname;
  const proto = req.headers["sec-websocket-protocol"] || "";
  if (u === "/ws" || u === "/") {
    if (proto.includes("roblox")) handleWS(ws, req, "roblox");
    else if (proto.includes("mcp")) handleWS(ws, req, "mcp");
    else handleWS(ws, req, "gui");
  } else {
    ws.close(1000, "use /ws");
  }
});

server.listen(PORT, "0.0.0.0", () => {
  LOG(`========================================`);
  LOG(`  Roblox AI MCP Bridge Server v1.0`);
  LOG(`========================================`);
  LOG(`  HTTP/GUI:  http://localhost:${PORT}/`);
  LOG(`  WS 端点:   ws://localhost:${PORT}/ws`);
  LOG(`  Roblox 执行器连接: ws://<IP>:${PORT}/ws (protocol: roblox)`);
  LOG(`  Operit MCP 连接:  ws://<IP>:${PORT}/ws (protocol: mcp)`);
  LOG(`========================================`);
  LOG(`  📱 手机端访问: http://<电脑IP>:${PORT}/`);
  LOG(`  🤖 Operit 配置为远程 MCP 插件:`);
  LOG(`     endpoint: ws://<电脑IP>:${PORT}/ws`);
  LOG(`     connectionType: websocket`);
  LOG(`     bearerToken: (留空)`);
  LOG(`========================================`);
});